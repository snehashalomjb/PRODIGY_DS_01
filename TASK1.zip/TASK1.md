# Task 1

## importing necessary libraries


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```

## Reading CSV file


```python
df=pd.read_csv("worldpopulationdata.csv")
```

## checking top 5 rows data


```python
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Series Name</th>
      <th>Series Code</th>
      <th>Country Name</th>
      <th>Country Code</th>
      <th>2022</th>
      <th>2021</th>
      <th>2020</th>
      <th>2019</th>
      <th>2018</th>
      <th>2017</th>
      <th>...</th>
      <th>2010</th>
      <th>2009</th>
      <th>2008</th>
      <th>2007</th>
      <th>2006</th>
      <th>2005</th>
      <th>2004</th>
      <th>2003</th>
      <th>2002</th>
      <th>2001</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>41128771.0</td>
      <td>40099462.0</td>
      <td>38972230.0</td>
      <td>37769499.0</td>
      <td>36686784.0</td>
      <td>35643418.0</td>
      <td>...</td>
      <td>28189672.0</td>
      <td>27385307.0</td>
      <td>26427199.0</td>
      <td>25903301.0</td>
      <td>25442944.0</td>
      <td>24411191.0</td>
      <td>23553551.0</td>
      <td>22645130.0</td>
      <td>21000256.0</td>
      <td>19688632.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>Albania</td>
      <td>ALB</td>
      <td>2775634.0</td>
      <td>2811666.0</td>
      <td>2837849.0</td>
      <td>2854191.0</td>
      <td>2866376.0</td>
      <td>2873457.0</td>
      <td>...</td>
      <td>2913021.0</td>
      <td>2927519.0</td>
      <td>2947314.0</td>
      <td>2970017.0</td>
      <td>2992547.0</td>
      <td>3011487.0</td>
      <td>3026939.0</td>
      <td>3039616.0</td>
      <td>3051010.0</td>
      <td>3060173.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>Algeria</td>
      <td>DZA</td>
      <td>44903225.0</td>
      <td>44177969.0</td>
      <td>43451666.0</td>
      <td>42705368.0</td>
      <td>41927007.0</td>
      <td>41136546.0</td>
      <td>...</td>
      <td>35856344.0</td>
      <td>35196037.0</td>
      <td>34569592.0</td>
      <td>33983827.0</td>
      <td>33435080.0</td>
      <td>32956690.0</td>
      <td>32510186.0</td>
      <td>32055883.0</td>
      <td>31624696.0</td>
      <td>31200985.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>American Samoa</td>
      <td>ASM</td>
      <td>44273.0</td>
      <td>45035.0</td>
      <td>46189.0</td>
      <td>47321.0</td>
      <td>48424.0</td>
      <td>49463.0</td>
      <td>...</td>
      <td>54849.0</td>
      <td>55366.0</td>
      <td>55891.0</td>
      <td>56383.0</td>
      <td>56837.0</td>
      <td>57254.0</td>
      <td>57626.0</td>
      <td>57941.0</td>
      <td>58177.0</td>
      <td>58324.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>Andorra</td>
      <td>AND</td>
      <td>79824.0</td>
      <td>79034.0</td>
      <td>77700.0</td>
      <td>76343.0</td>
      <td>75013.0</td>
      <td>73837.0</td>
      <td>...</td>
      <td>71519.0</td>
      <td>73852.0</td>
      <td>76055.0</td>
      <td>78168.0</td>
      <td>80221.0</td>
      <td>79826.0</td>
      <td>76933.0</td>
      <td>73907.0</td>
      <td>70849.0</td>
      <td>67820.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>



## checking data from bottom


```python
df.tail(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Series Name</th>
      <th>Series Code</th>
      <th>Country Name</th>
      <th>Country Code</th>
      <th>2022</th>
      <th>2021</th>
      <th>2020</th>
      <th>2019</th>
      <th>2018</th>
      <th>2017</th>
      <th>...</th>
      <th>2010</th>
      <th>2009</th>
      <th>2008</th>
      <th>2007</th>
      <th>2006</th>
      <th>2005</th>
      <th>2004</th>
      <th>2003</th>
      <th>2002</th>
      <th>2001</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1080</th>
      <td>Population, male (% of total population)</td>
      <td>SP.POP.TOTL.MA.ZS</td>
      <td>Virgin Islands (U.S.)</td>
      <td>VIR</td>
      <td>46.613382</td>
      <td>46.764444</td>
      <td>46.914637</td>
      <td>47.057307</td>
      <td>47.185912</td>
      <td>47.314214</td>
      <td>...</td>
      <td>47.801059</td>
      <td>47.834540</td>
      <td>47.870063</td>
      <td>47.877604</td>
      <td>47.870702</td>
      <td>47.852669</td>
      <td>47.825150</td>
      <td>47.789128</td>
      <td>47.754932</td>
      <td>47.725126</td>
    </tr>
    <tr>
      <th>1081</th>
      <td>Population, male (% of total population)</td>
      <td>SP.POP.TOTL.MA.ZS</td>
      <td>West Bank and Gaza</td>
      <td>PSE</td>
      <td>49.893678</td>
      <td>49.877839</td>
      <td>49.858957</td>
      <td>49.835542</td>
      <td>49.811374</td>
      <td>49.785969</td>
      <td>...</td>
      <td>49.876336</td>
      <td>49.898677</td>
      <td>49.921445</td>
      <td>49.947631</td>
      <td>49.983323</td>
      <td>50.028649</td>
      <td>50.089953</td>
      <td>50.167544</td>
      <td>50.248196</td>
      <td>50.321633</td>
    </tr>
    <tr>
      <th>1082</th>
      <td>Population, male (% of total population)</td>
      <td>SP.POP.TOTL.MA.ZS</td>
      <td>Yemen, Rep.</td>
      <td>YEM</td>
      <td>50.519031</td>
      <td>50.538516</td>
      <td>50.554317</td>
      <td>50.571320</td>
      <td>50.596614</td>
      <td>50.616964</td>
      <td>...</td>
      <td>50.594170</td>
      <td>50.582692</td>
      <td>50.568876</td>
      <td>50.553633</td>
      <td>50.539012</td>
      <td>50.522514</td>
      <td>50.502720</td>
      <td>50.481666</td>
      <td>50.459941</td>
      <td>50.437238</td>
    </tr>
    <tr>
      <th>1083</th>
      <td>Population, male (% of total population)</td>
      <td>SP.POP.TOTL.MA.ZS</td>
      <td>Zambia</td>
      <td>ZMB</td>
      <td>49.344602</td>
      <td>49.344951</td>
      <td>49.338301</td>
      <td>49.326233</td>
      <td>49.309087</td>
      <td>49.288400</td>
      <td>...</td>
      <td>49.056379</td>
      <td>48.981404</td>
      <td>48.888443</td>
      <td>48.784780</td>
      <td>48.676944</td>
      <td>48.571398</td>
      <td>48.476900</td>
      <td>48.393634</td>
      <td>48.313646</td>
      <td>48.229968</td>
    </tr>
    <tr>
      <th>1084</th>
      <td>Population, male (% of total population)</td>
      <td>SP.POP.TOTL.MA.ZS</td>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>47.214139</td>
      <td>47.167153</td>
      <td>47.130679</td>
      <td>47.099796</td>
      <td>47.076238</td>
      <td>47.051613</td>
      <td>...</td>
      <td>46.995893</td>
      <td>47.049546</td>
      <td>47.106068</td>
      <td>47.166435</td>
      <td>47.190963</td>
      <td>47.231433</td>
      <td>47.324096</td>
      <td>47.387633</td>
      <td>47.428426</td>
      <td>47.460469</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>



## checking the columns of the dataset


```python
df.columns
```




    Index(['Series Name', 'Series Code', 'Country Name', 'Country Code', '2022',
           '2021', '2020', '2019', '2018', '2017', '2016', '2015', '2014', '2013',
           '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004',
           '2003', '2002', '2001'],
          dtype='object')



## some information about dataset


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1085 entries, 0 to 1084
    Data columns (total 26 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   Series Name   1085 non-null   object 
     1   Series Code   1085 non-null   object 
     2   Country Name  1085 non-null   object 
     3   Country Code  1085 non-null   object 
     4   2022          1085 non-null   float64
     5   2021          1085 non-null   float64
     6   2020          1085 non-null   float64
     7   2019          1085 non-null   float64
     8   2018          1085 non-null   float64
     9   2017          1085 non-null   float64
     10  2016          1085 non-null   float64
     11  2015          1085 non-null   float64
     12  2014          1085 non-null   float64
     13  2013          1085 non-null   float64
     14  2012          1085 non-null   float64
     15  2011          1085 non-null   float64
     16  2010          1085 non-null   float64
     17  2009          1085 non-null   float64
     18  2008          1085 non-null   float64
     19  2007          1085 non-null   float64
     20  2006          1085 non-null   float64
     21  2005          1085 non-null   float64
     22  2004          1085 non-null   float64
     23  2003          1085 non-null   float64
     24  2002          1085 non-null   float64
     25  2001          1085 non-null   float64
    dtypes: float64(22), object(4)
    memory usage: 220.5+ KB
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>2022</th>
      <th>2021</th>
      <th>2020</th>
      <th>2019</th>
      <th>2018</th>
      <th>2017</th>
      <th>2016</th>
      <th>2015</th>
      <th>2014</th>
      <th>2013</th>
      <th>...</th>
      <th>2010</th>
      <th>2009</th>
      <th>2008</th>
      <th>2007</th>
      <th>2006</th>
      <th>2005</th>
      <th>2004</th>
      <th>2003</th>
      <th>2002</th>
      <th>2001</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>...</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
      <td>1.085000e+03</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.461378e+07</td>
      <td>1.449711e+07</td>
      <td>1.437307e+07</td>
      <td>1.422876e+07</td>
      <td>1.407966e+07</td>
      <td>1.392568e+07</td>
      <td>1.376711e+07</td>
      <td>1.360705e+07</td>
      <td>1.344625e+07</td>
      <td>1.328368e+07</td>
      <td>...</td>
      <td>1.280537e+07</td>
      <td>1.265031e+07</td>
      <td>1.249535e+07</td>
      <td>1.234099e+07</td>
      <td>1.218858e+07</td>
      <td>1.203685e+07</td>
      <td>1.188626e+07</td>
      <td>1.173626e+07</td>
      <td>1.158653e+07</td>
      <td>1.143598e+07</td>
    </tr>
    <tr>
      <th>std</th>
      <td>7.832944e+07</td>
      <td>7.801505e+07</td>
      <td>7.763257e+07</td>
      <td>7.712985e+07</td>
      <td>7.657562e+07</td>
      <td>7.596457e+07</td>
      <td>7.528760e+07</td>
      <td>7.461740e+07</td>
      <td>7.394894e+07</td>
      <td>7.325356e+07</td>
      <td>...</td>
      <td>7.113128e+07</td>
      <td>7.047509e+07</td>
      <td>6.982016e+07</td>
      <td>6.915934e+07</td>
      <td>6.849229e+07</td>
      <td>6.780708e+07</td>
      <td>6.710041e+07</td>
      <td>6.638386e+07</td>
      <td>6.565651e+07</td>
      <td>6.490862e+07</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.749000e+01</td>
      <td>2.732503e+01</td>
      <td>2.735104e+01</td>
      <td>2.676295e+01</td>
      <td>2.573928e+01</td>
      <td>2.508394e+01</td>
      <td>2.464721e+01</td>
      <td>2.474106e+01</td>
      <td>2.540718e+01</td>
      <td>2.594943e+01</td>
      <td>...</td>
      <td>2.425072e+01</td>
      <td>2.339422e+01</td>
      <td>2.356750e+01</td>
      <td>2.520779e+01</td>
      <td>2.831990e+01</td>
      <td>3.096426e+01</td>
      <td>3.129133e+01</td>
      <td>3.137472e+01</td>
      <td>3.146521e+01</td>
      <td>3.156689e+01</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>5.034029e+01</td>
      <td>5.035172e+01</td>
      <td>5.034171e+01</td>
      <td>5.033040e+01</td>
      <td>5.033917e+01</td>
      <td>5.033041e+01</td>
      <td>5.033966e+01</td>
      <td>5.033554e+01</td>
      <td>5.032504e+01</td>
      <td>5.033767e+01</td>
      <td>...</td>
      <td>5.034833e+01</td>
      <td>5.036836e+01</td>
      <td>5.037388e+01</td>
      <td>5.036880e+01</td>
      <td>5.038085e+01</td>
      <td>5.037186e+01</td>
      <td>5.036210e+01</td>
      <td>5.039432e+01</td>
      <td>5.039371e+01</td>
      <td>5.038254e+01</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.465500e+05</td>
      <td>1.463660e+05</td>
      <td>1.461650e+05</td>
      <td>1.459570e+05</td>
      <td>1.457520e+05</td>
      <td>1.441350e+05</td>
      <td>1.406060e+05</td>
      <td>1.371850e+05</td>
      <td>1.349620e+05</td>
      <td>1.328960e+05</td>
      <td>...</td>
      <td>1.263090e+05</td>
      <td>1.244660e+05</td>
      <td>1.228070e+05</td>
      <td>1.209490e+05</td>
      <td>1.190890e+05</td>
      <td>1.171330e+05</td>
      <td>1.152950e+05</td>
      <td>1.136960e+05</td>
      <td>1.134500e+05</td>
      <td>1.136410e+05</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>5.903468e+06</td>
      <td>5.856733e+06</td>
      <td>5.831404e+06</td>
      <td>5.814422e+06</td>
      <td>5.774185e+06</td>
      <td>5.686999e+06</td>
      <td>5.629265e+06</td>
      <td>5.544490e+06</td>
      <td>5.524552e+06</td>
      <td>5.480089e+06</td>
      <td>...</td>
      <td>5.267970e+06</td>
      <td>5.187356e+06</td>
      <td>5.100083e+06</td>
      <td>5.062560e+06</td>
      <td>5.007301e+06</td>
      <td>4.989584e+06</td>
      <td>4.813244e+06</td>
      <td>4.758988e+06</td>
      <td>4.698968e+06</td>
      <td>4.535518e+06</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.417173e+09</td>
      <td>1.412360e+09</td>
      <td>1.411100e+09</td>
      <td>1.407745e+09</td>
      <td>1.402760e+09</td>
      <td>1.396215e+09</td>
      <td>1.387790e+09</td>
      <td>1.379860e+09</td>
      <td>1.371860e+09</td>
      <td>1.363240e+09</td>
      <td>...</td>
      <td>1.337705e+09</td>
      <td>1.331260e+09</td>
      <td>1.324655e+09</td>
      <td>1.317885e+09</td>
      <td>1.311020e+09</td>
      <td>1.303720e+09</td>
      <td>1.296075e+09</td>
      <td>1.288400e+09</td>
      <td>1.280400e+09</td>
      <td>1.271850e+09</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 22 columns</p>
</div>



## Checking for duplicates values


```python
df.duplicated().sum()
```




    np.int64(0)



## Checking for missing values


```python
df.isna().sum()
```




    Series Name     0
    Series Code     0
    Country Name    0
    Country Code    0
    2022            0
    2021            0
    2020            0
    2019            0
    2018            0
    2017            0
    2016            0
    2015            0
    2014            0
    2013            0
    2012            0
    2011            0
    2010            0
    2009            0
    2008            0
    2007            0
    2006            0
    2005            0
    2004            0
    2003            0
    2002            0
    2001            0
    dtype: int64



## Checking unique values for columns


```python
print(df['Country Name'].unique())
print("\n Total no of unique countries:",df['Country Name'].nunique())
```

    ['Afghanistan' 'Albania' 'Algeria' 'American Samoa' 'Andorra' 'Angola'
     'Antigua and Barbuda' 'Argentina' 'Armenia' 'Aruba' 'Australia' 'Austria'
     'Azerbaijan' 'Bahamas, The' 'Bahrain' 'Bangladesh' 'Barbados' 'Belarus'
     'Belgium' 'Belize' 'Benin' 'Bermuda' 'Bhutan' 'Bolivia'
     'Bosnia and Herzegovina' 'Botswana' 'Brazil' 'British Virgin Islands'
     'Brunei Darussalam' 'Bulgaria' 'Burkina Faso' 'Burundi' 'Cabo Verde'
     'Cambodia' 'Cameroon' 'Canada' 'Cayman Islands'
     'Central African Republic' 'Chad' 'Channel Islands' 'Chile' 'China'
     'Colombia' 'Comoros' 'Congo, Dem. Rep.' 'Congo, Rep.' 'Costa Rica'
     "Cote d'Ivoire" 'Croatia' 'Cuba' 'Curacao' 'Cyprus' 'Czechia' 'Denmark'
     'Djibouti' 'Dominica' 'Dominican Republic' 'Ecuador' 'Egypt, Arab Rep.'
     'El Salvador' 'Equatorial Guinea' 'Eritrea' 'Estonia' 'Eswatini'
     'Ethiopia' 'Faroe Islands' 'Fiji' 'Finland' 'France' 'French Polynesia'
     'Gabon' 'Gambia, The' 'Georgia' 'Germany' 'Ghana' 'Gibraltar' 'Greece'
     'Greenland' 'Grenada' 'Guam' 'Guatemala' 'Guinea' 'Guinea-Bissau'
     'Guyana' 'Haiti' 'Honduras' 'Hong Kong SAR, China' 'Hungary' 'Iceland'
     'India' 'Indonesia' 'Iran, Islamic Rep.' 'Iraq' 'Ireland' 'Isle of Man'
     'Israel' 'Italy' 'Jamaica' 'Japan' 'Jordan' 'Kazakhstan' 'Kenya'
     'Kiribati' "Korea, Dem. People's Rep." 'Korea, Rep.' 'Kosovo' 'Kuwait'
     'Kyrgyz Republic' 'Lao PDR' 'Latvia' 'Lebanon' 'Lesotho' 'Liberia'
     'Libya' 'Liechtenstein' 'Lithuania' 'Luxembourg' 'Macao SAR, China'
     'Madagascar' 'Malawi' 'Malaysia' 'Maldives' 'Mali' 'Malta'
     'Marshall Islands' 'Mauritania' 'Mauritius' 'Mexico'
     'Micronesia, Fed. Sts.' 'Moldova' 'Monaco' 'Mongolia' 'Montenegro'
     'Morocco' 'Mozambique' 'Myanmar' 'Namibia' 'Nauru' 'Nepal' 'Netherlands'
     'New Caledonia' 'New Zealand' 'Nicaragua' 'Niger' 'Nigeria'
     'North Macedonia' 'Northern Mariana Islands' 'Norway' 'Oman' 'Pakistan'
     'Palau' 'Panama' 'Papua New Guinea' 'Paraguay' 'Peru' 'Philippines'
     'Poland' 'Portugal' 'Puerto Rico' 'Qatar' 'Romania' 'Russian Federation'
     'Rwanda' 'Samoa' 'San Marino' 'Sao Tome and Principe' 'Saudi Arabia'
     'Senegal' 'Serbia' 'Seychelles' 'Sierra Leone' 'Singapore'
     'Sint Maarten (Dutch part)' 'Slovak Republic' 'Slovenia'
     'Solomon Islands' 'Somalia' 'South Africa' 'South Sudan' 'Spain'
     'Sri Lanka' 'St. Kitts and Nevis' 'St. Lucia' 'St. Martin (French part)'
     'St. Vincent and the Grenadines' 'Sudan' 'Suriname' 'Sweden'
     'Switzerland' 'Syrian Arab Republic' 'Tajikistan' 'Tanzania' 'Thailand'
     'Timor-Leste' 'Togo' 'Tonga' 'Trinidad and Tobago' 'Tunisia' 'Turkiye'
     'Turkmenistan' 'Turks and Caicos Islands' 'Tuvalu' 'Uganda' 'Ukraine'
     'United Arab Emirates' 'United Kingdom' 'United States' 'Uruguay'
     'Uzbekistan' 'Vanuatu' 'Venezuela, RB' 'Vietnam' 'Virgin Islands (U.S.)'
     'West Bank and Gaza' 'Yemen, Rep.' 'Zambia' 'Zimbabwe']
    
     Total no of unique countries: 217
    

## checking country code


```python
print(df['Country Code'].unique())
print("\n Total no of unique country Code:",df['Country Code'].nunique())
```

    ['AFG' 'ALB' 'DZA' 'ASM' 'AND' 'AGO' 'ATG' 'ARG' 'ARM' 'ABW' 'AUS' 'AUT'
     'AZE' 'BHS' 'BHR' 'BGD' 'BRB' 'BLR' 'BEL' 'BLZ' 'BEN' 'BMU' 'BTN' 'BOL'
     'BIH' 'BWA' 'BRA' 'VGB' 'BRN' 'BGR' 'BFA' 'BDI' 'CPV' 'KHM' 'CMR' 'CAN'
     'CYM' 'CAF' 'TCD' 'CHI' 'CHL' 'CHN' 'COL' 'COM' 'COD' 'COG' 'CRI' 'CIV'
     'HRV' 'CUB' 'CUW' 'CYP' 'CZE' 'DNK' 'DJI' 'DMA' 'DOM' 'ECU' 'EGY' 'SLV'
     'GNQ' 'ERI' 'EST' 'SWZ' 'ETH' 'FRO' 'FJI' 'FIN' 'FRA' 'PYF' 'GAB' 'GMB'
     'GEO' 'DEU' 'GHA' 'GIB' 'GRC' 'GRL' 'GRD' 'GUM' 'GTM' 'GIN' 'GNB' 'GUY'
     'HTI' 'HND' 'HKG' 'HUN' 'ISL' 'IND' 'IDN' 'IRN' 'IRQ' 'IRL' 'IMN' 'ISR'
     'ITA' 'JAM' 'JPN' 'JOR' 'KAZ' 'KEN' 'KIR' 'PRK' 'KOR' 'XKX' 'KWT' 'KGZ'
     'LAO' 'LVA' 'LBN' 'LSO' 'LBR' 'LBY' 'LIE' 'LTU' 'LUX' 'MAC' 'MDG' 'MWI'
     'MYS' 'MDV' 'MLI' 'MLT' 'MHL' 'MRT' 'MUS' 'MEX' 'FSM' 'MDA' 'MCO' 'MNG'
     'MNE' 'MAR' 'MOZ' 'MMR' 'NAM' 'NRU' 'NPL' 'NLD' 'NCL' 'NZL' 'NIC' 'NER'
     'NGA' 'MKD' 'MNP' 'NOR' 'OMN' 'PAK' 'PLW' 'PAN' 'PNG' 'PRY' 'PER' 'PHL'
     'POL' 'PRT' 'PRI' 'QAT' 'ROU' 'RUS' 'RWA' 'WSM' 'SMR' 'STP' 'SAU' 'SEN'
     'SRB' 'SYC' 'SLE' 'SGP' 'SXM' 'SVK' 'SVN' 'SLB' 'SOM' 'ZAF' 'SSD' 'ESP'
     'LKA' 'KNA' 'LCA' 'MAF' 'VCT' 'SDN' 'SUR' 'SWE' 'CHE' 'SYR' 'TJK' 'TZA'
     'THA' 'TLS' 'TGO' 'TON' 'TTO' 'TUN' 'TUR' 'TKM' 'TCA' 'TUV' 'UGA' 'UKR'
     'ARE' 'GBR' 'USA' 'URY' 'UZB' 'VUT' 'VEN' 'VNM' 'VIR' 'PSE' 'YEM' 'ZMB'
     'ZWE']
    
     Total no of unique country Code: 217
    

## Dropping unnecessary columns


```python
df.drop(['Series Name','Country Name'],axis=1,inplace=True)
```

## Extraction of top 10 countries with repect to total population


```python
# Filter data for total population
total_population_data = df[df[ 'Series Code' ] == 'SP.POP.TOTL']
                           
# Sort data based on the total population for 2022
total_population_sorted = total_population_data.sort_values(by="2022", ascending=False)

# Get the top ten countries with the highest total population for 2022
total_top_ten_countries = total_population_sorted.head(10)
print("Top ten countries of total population\n")
print(total_top_ten_countries[['Country Code' ]])

```

    Top ten countries of total population
    
        Country Code
    89           IND
    41           CHN
    206          USA
    90           IDN
    149          PAK
    144          NGA
    26           BRA
    15           BGD
    161          RUS
    127          MEX
    

## Bar plot

## Top ten countriers of total population in year 2022 and 2016


```python
# Create the bor plot

plt.figure(figsize=(15, 6))
plt.subplot(2,2,1)
sns.barplot(x="2022", y="Country Code", data=total_top_ten_countries, palette="coolwarm")
plt.title("top Ten Countries of Total Population (2022)", fontsize=10)
plt.xlabel("Total Population", fontsize=10)
plt.ylabel("Country", fontsize=10)
plt.show()

# Create the bar plot

plt.figure(figsize=(15, 6))
plt.subplot (2,2,2)
sns.barplot(x="2016", y="Country Code", data=total_top_ten_countries, palette="coolwarm")
plt. title("Top Ten Countries of Total Population (2016)", fontsize=10)
plt.xlabel("Total Population", fontsize=10)
plt.ylabel("Country", fontsize=10)
plt.show()

```

    C:\Users\sneha\AppData\Local\Temp\ipykernel_6308\1066451370.py:5: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x="2022", y="Country Code", data=total_top_ten_countries, palette="coolwarm")
    


    
![png](output_28_1.png)
    


    C:\Users\sneha\AppData\Local\Temp\ipykernel_6308\1066451370.py:15: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x="2016", y="Country Code", data=total_top_ten_countries, palette="coolwarm")
    


    
![png](output_28_3.png)
    


## Extraction of bottom 10 countries with resspect to total population


```python

#sort data based on the total population for 2022
total_population_sorted = total_population_data.sort_values(by="2022", ascending=True)

# Get the bottom ten countries with the highest total population for 2022
total_bottom_ten_countries = total_population_sorted.head(10)
print("Bottom ten countries of total population\n")
print(total_bottom_ten_countries[['Country Code' ]])

```

    Bottom ten countries of total population
    
        Country Code
    201          TUV
    137          NRU
    150          PLW
    27           VGB
    183          MAF
    75           GIB
    164          SMR
    130          MCO
    114          LIE
    124          MHL
    

## bottom ten countriers of total population in year 2022 and 2016


```python
# Create the bor plot
plt.figure(figsize=(15, 6))
plt.subplot(2,2,1)
sns.barplot(x="2022", y="Country Code", data=total_bottom_ten_countries, palette="coolwarm")
plt.title("Bottom Ten Countries of Total Population (2022)", fontsize=10)
plt.xlabel("Total Population", fontsize=10)
plt.ylabel("Country", fontsize=10)
plt.show()


# Create the bar plot
plt.figure(figsize=(15, 6))
plt.subplot (2,2,2)
sns.barplot(x="2016", y="Country Code", data=total_bottom_ten_countries, palette="coolwarm")
plt. title("Bottom Ten Countries of Total Population (2016)", fontsize=10)
plt.xlabel("Total Population", fontsize=10)
plt.ylabel("Country", fontsize=10)
plt.show()

```

    C:\Users\sneha\AppData\Local\Temp\ipykernel_6308\2617623145.py:4: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x="2022", y="Country Code", data=total_bottom_ten_countries, palette="coolwarm")
    


    
![png](output_32_1.png)
    


    C:\Users\sneha\AppData\Local\Temp\ipykernel_6308\2617623145.py:14: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x="2016", y="Country Code", data=total_bottom_ten_countries, palette="coolwarm")
    


    
![png](output_32_3.png)
    


## Extraction of top 10 countries with highest male population


```python
#Filter data for male population
male_population_data = df[df['Series Code'] =='SP.POP.TOTL.MA.IN']

#Sort data based on the male population for 2022
male_population_sorted =male_population_data.sort_values(by="2022",ascending=False)

#Get the top 10 countries with the highest male population for 2022
male_top_ten_countries = male_population_sorted.head(10)
print("Top ten countries of male population")
print(male_top_ten_countries[['Country Code']])
```

    Top ten countries of male population
        Country Code
    523          IND
    475          CHN
    640          USA
    524          IDN
    583          PAK
    578          NGA
    460          BRA
    449          BGD
    595          RUS
    561          MEX
    

## Top ten countries with highest female population


```python
#Filter data for female population
female_population_data = df[df['Series Code'] =='SP.POP.TOTL.MA.IN']

#Sort data based on the male population for 2022
female_population_sorted =female_population_data.sort_values(by="2022",ascending=False)

#Get the top 10 countries with the highest female population for 2022
female_top_ten_countries = female_population_sorted.head(10)
print("Top ten countries of female population")
print(female_top_ten_countries[['Country Code']])
```

    Top ten countries of female population
        Country Code
    523          IND
    475          CHN
    640          USA
    524          IDN
    583          PAK
    578          NGA
    460          BRA
    449          BGD
    595          RUS
    561          MEX
    

## Top ten countries with highest male and female population in 2022


```python

# Create the bor plot

plt.figure(figsize=(15, 6))
plt.subplot(2,2,1)
sns.barplot(x="2022", y="Country Code", data=male_top_ten_countries, palette="viridis")
plt.title("top Ten Countries of male Population (2022)", fontsize=10)
plt.xlabel("Male Population", fontsize=10)
plt.ylabel("Country", fontsize=10)
plt.show()

# Create the bar plot

plt.figure(figsize=(15, 6))
plt.subplot (2,2,2)
sns.barplot(x="2016", y="Country Code", data=female_top_ten_countries, palette="viridis")
plt. title("Top Ten Countries of female Population (2016)", fontsize=10)
plt.xlabel("Female Population", fontsize=10)
plt.ylabel("Country", fontsize=10)
plt.show()


```

    C:\Users\sneha\AppData\Local\Temp\ipykernel_6308\2034849361.py:5: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x="2022", y="Country Code", data=male_top_ten_countries, palette="viridis")
    


    
![png](output_38_1.png)
    


    C:\Users\sneha\AppData\Local\Temp\ipykernel_6308\2034849361.py:15: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x="2016", y="Country Code", data=female_top_ten_countries, palette="viridis")
    


    
![png](output_38_3.png)
    


## Stacked Bar plot

## Top 10 Countries with Male & Female Population


```python
#merge male and female population data on 'Country Code'
merge_data=pd.merge(male_population_data,female_population_data, on="Country Code", suffixes=("_male","_female"))  
                             
```


```python
#merged data
#calculate the total population for each country (male + female)
merge_data["Total population"] =merge_data["2022_male"] + merge_data["2022_female"]
```


```python
merge_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Series Code_male</th>
      <th>Country Code</th>
      <th>2022_male</th>
      <th>2021_male</th>
      <th>2020_male</th>
      <th>2019_male</th>
      <th>2018_male</th>
      <th>2017_male</th>
      <th>2016_male</th>
      <th>2015_male</th>
      <th>...</th>
      <th>2010_female</th>
      <th>2009_female</th>
      <th>2008_female</th>
      <th>2007_female</th>
      <th>2006_female</th>
      <th>2005_female</th>
      <th>2004_female</th>
      <th>2003_female</th>
      <th>2002_female</th>
      <th>2001_female</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>SP.POP.TOTL.MA.IN</td>
      <td>AFG</td>
      <td>20766442.0</td>
      <td>20254878.0</td>
      <td>19692301.0</td>
      <td>19090409.0</td>
      <td>18549862.0</td>
      <td>18028696.0</td>
      <td>17520861.0</td>
      <td>17071446.0</td>
      <td>...</td>
      <td>14240377.0</td>
      <td>13827977.0</td>
      <td>13339006.0</td>
      <td>13067961.0</td>
      <td>12828447.0</td>
      <td>12302104.0</td>
      <td>11862726.0</td>
      <td>11397483.0</td>
      <td>10562202.0</td>
      <td>9895467.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SP.POP.TOTL.MA.IN</td>
      <td>ALB</td>
      <td>1384548.0</td>
      <td>1404454.0</td>
      <td>1419264.0</td>
      <td>1428828.0</td>
      <td>1435881.0</td>
      <td>1440219.0</td>
      <td>1442176.0</td>
      <td>1444890.0</td>
      <td>...</td>
      <td>1458913.0</td>
      <td>1464541.0</td>
      <td>1472476.0</td>
      <td>1481621.0</td>
      <td>1490629.0</td>
      <td>1497909.0</td>
      <td>1503547.0</td>
      <td>1508084.0</td>
      <td>1512520.0</td>
      <td>1516640.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>SP.POP.TOTL.MA.IN</td>
      <td>DZA</td>
      <td>22862237.0</td>
      <td>22497244.0</td>
      <td>22132899.0</td>
      <td>21756903.0</td>
      <td>21362603.0</td>
      <td>20961313.0</td>
      <td>20556314.0</td>
      <td>20152232.0</td>
      <td>...</td>
      <td>18282636.0</td>
      <td>17946941.0</td>
      <td>17628560.0</td>
      <td>17330466.0</td>
      <td>17050923.0</td>
      <td>16806416.0</td>
      <td>16578139.0</td>
      <td>16346159.0</td>
      <td>16126874.0</td>
      <td>15912853.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>SP.POP.TOTL.MA.IN</td>
      <td>ASM</td>
      <td>21873.0</td>
      <td>22289.0</td>
      <td>22921.0</td>
      <td>23535.0</td>
      <td>24134.0</td>
      <td>24701.0</td>
      <td>25240.0</td>
      <td>25739.0</td>
      <td>...</td>
      <td>27660.0</td>
      <td>27960.0</td>
      <td>28265.0</td>
      <td>28541.0</td>
      <td>28793.0</td>
      <td>29024.0</td>
      <td>29233.0</td>
      <td>29419.0</td>
      <td>29570.0</td>
      <td>29674.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>SP.POP.TOTL.MA.IN</td>
      <td>AND</td>
      <td>40786.0</td>
      <td>40361.0</td>
      <td>39615.0</td>
      <td>38842.0</td>
      <td>38071.0</td>
      <td>37380.0</td>
      <td>36628.0</td>
      <td>36188.0</td>
      <td>...</td>
      <td>36307.0</td>
      <td>37787.0</td>
      <td>39191.0</td>
      <td>40535.0</td>
      <td>41829.0</td>
      <td>41679.0</td>
      <td>40082.0</td>
      <td>38429.0</td>
      <td>36773.0</td>
      <td>35151.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 47 columns</p>
</div>




```python
#Sort data based on total population in decending order
sorted_data = merge_data.sort_values(by="Total population", ascending=False)
```

## Select the top 10 Countries with the highest total population


```python
top_10_countries = sorted_data.head(10)

```


```python
#create the staked bar plot
plt.figure(figsize=(12,6))
sns.barplot(x="Country Code",y="2022_female", data=top_10_countries, color="red", label="female Population")
sns.barplot(x="Country Code",y="2022_male", data=top_10_countries, bottom=top_10_countries["2022_female"], color="green", label="Male Population")
plt.xlabel("Country")
plt.ylabel("Population")
plt.legend()
plt.xticks(rotation=45,ha="right")
plt.show()
```


    
![png](output_47_0.png)
    




